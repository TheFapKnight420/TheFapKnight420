public class Pokemon {
    private String name;
    private String type;
    private int level;
    private Item pokemonBall;

    public Pokemon(String name, String type, int level) {
        this.name = name;
        this.type = type;
        this.level = level;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public int getDamage() {
        int damage = 10;
        return damage * level;
    }

    public int getLevel() {
        return level;
    }

    public int getHealth() {
        int health = 40;
        return health * level;
    }
    public void createBall(Pokemon pokemon){
        this.pokemonBall = new Item((pokemon.getName() + ", PokemonBall"), "PokemonBall", 1);
    }

    public Item getPokemonBall() {
        return pokemonBall;
    }

    public Pokemon generatePokemon(){
        int randomNameChooser = (int) (Math.random() * 4 +1);
        int randomLevel = (int) (Math.random() * 5 +1);
        String randomName = "";
        String type = "";
        switch (randomNameChooser){
            case 1 :
                randomName = "Pikachu";
                 type = "Electric";
                 break;
            case 2 :
                randomName = "Eevee";
                type = "Normal";
                break;
            case 3 :
                randomName = "Snorlax";
                type = "Normal";
                break;
            case 4 :
                randomName = "Charizard";
                type = "Fire";
                break;
            case 5 :
                randomName = "Piplup";
                type = "Water";
                break;
        }
        Pokemon randomPokemon = new Pokemon(randomName, type ,randomLevel );
        return randomPokemon;



    }
}
