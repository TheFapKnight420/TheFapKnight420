import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Starting game..........4...3...2..1..Done!");
        System.out.println("""
                   Game by:
                   MM    MM
                  M  M  M  M
                 M    M     M
                M            M
                Pokemon Game v0.01
                Please enter your name:""");
        String playerName = scanner.nextLine();
        Player newPlayer = new Player(playerName);
        System.out.println("Welcome to your adventure " + newPlayer.getName() + "!");
        newPlayer.managePokemons(new Pokemon("Pickachu", "Electrical", 1),"Add");
        newPlayer.managePokemons(new Pokemon("lol", "fuck", 2),"Add");
        newPlayer.inventoryManagement(new Item("Potion", "helath", 1), "AddItem");
        newPlayer.inventoryManagement(new Item("Health Potion", "health", 1), "AddItem");
        MainMenu(newPlayer);


    }

    public static void MainMenu(Player newPlayer) {
//        scanner.next();
        int choice = 0;

        while (choice != 6) {
            printOptions();
            choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("=======================\nItems in inventory:");
                    for (int i = 0; i < newPlayer.getItemArrayList().size(); i++) {
                        System.out.println("=======================\n" + (i + 1) + ". " + newPlayer.getItemArrayList().get(i).getName());

                    }
                    System.out.println("""
                            =======================
                            1.Go Back
                            2.Remove item
                            """);
                    choice = scanner.nextInt();
                    if (choice == 1) {
                        break;


                    } else if (choice == 2) {
                        System.out.println("Choose the item you want to remove");
                        choice = scanner.nextInt();
                        newPlayer.inventoryManagement(newPlayer.getItemArrayList().get(choice - 1), "Remove");

                    }

                    break;
                case 4:
                    System.out.println("=======================\nPokemons in inventory:");
                    for (int i = 0; i < newPlayer.getPokemonArrayList().size(); i++) {
                        System.out.println("=======================\n" + (i + 1) + ". " + newPlayer.getPokemonArrayList().get(i).getName() + ", level : " + newPlayer.getPokemonArrayList().get(i).getLevel());
                    }
                    System.out.println("""
                            =======================
                            1.Go Back
                            2.Release pokemon :(
                            """);
                    choice = scanner.nextInt();
                    if (choice == 1) {
                        break;
                    } else if (choice == 2) {
                        System.out.println("Choose the pokemon you want to remove");
                        choice = scanner.nextInt();
                        if(choice > newPlayer.getPokemonArrayList().size()){
                            System.out.println("Item is out of bounds");
                            choice = 0;
                            break;
                        }
                        newPlayer.managePokemons(newPlayer.getPokemonArrayList().get(choice-1), "Remove");
                        if(choice == 6){
                            choice = 0;
                        }

                    }

            }
        }
        closeGame();


    }

    public static void printOptions() {
        System.out.println("======================\n" + "Please type the number according to the wanted action");
        System.out.println("""
                1.Check Inventory *
                2.Check Stats *
                3.Move *
                4.Pokemons *
                5.Itmes *
                6.Quit game *
                """);
    }

    public static void closeGame() {
        System.out.println("Shutting game \n" +
                "see you late!");
    }
}