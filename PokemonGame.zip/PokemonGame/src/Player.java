import java.util.ArrayList;

public class Player {
    private String name;
    private int energy = 100;
    private int inventoryCap = 5;
    private int currentInventorySpace = 0;
    private int level = 1;
    private int xp = 0;
    private ArrayList<Pokemon> pokemonArrayList;
    private ArrayList<Item> itemArrayList;


    public Player(String name) {
        this.name = name;
        pokemonArrayList = new ArrayList<>();
        itemArrayList = new ArrayList<>();

    }

    public String getName() {
        return name;
    }

    public ArrayList<Pokemon> getPokemonArrayList() {
        return pokemonArrayList;
    }

    public ArrayList<Item> getItemArrayList() {
        return itemArrayList;
    }

    public int getEnergy() {
        return energy;
    }

    public int getInventoryCap() {
        return inventoryCap;
    }

    //    public void PlayerLevelUp(){
//        System.out.println("Player has level up from level " + level + " to level ");
//    }
    private boolean hasLeveledUp() {
        boolean isTrue = false;
        if (xp <= 0) {
            return false;
        }
        while (xp >= 100 * level) {
            level++;
            xp -= 100 * level;
            System.out.println("Leveled up ******8___8******");
            isTrue = true;
        }
        return isTrue;
    }

    public void addXp(int xp) {
        this.xp += xp;
        if (hasLeveledUp()) {
            System.out.println("You have leveled up to " + level);
        }
    }

    public void energyStatDecrease(int energyToDecrease) {
        if (energyToDecrease != 0)
            energy = energy - energyToDecrease;
    }

    public void RestOrPotion(int energyToGain) {
        if (energyToGain != 0) {
            energy = energy + energyToGain;
        }
    }

    public void inventoryManagement(Item item, String action) {
        if (action.equals("AddItem")) {
            if (hasRoom(item)) {
                currentInventorySpace += item.getInventorySpaceValue();
                itemArrayList.add(item);
                System.out.println("Added " + item.getName() + " successfully! \nSpace left in backPack : " + (inventoryCap - currentInventorySpace));
            }
        } else if ((action.equals("Remove") || action.equals("Use")) && !item.getType().equals("PokemonBall")) {
            currentInventorySpace -= item.getInventorySpaceValue();
            itemArrayList.remove(item);
            System.out.println("Removed " + item.getName() + " successfully! \nSpace left in backPack : " + (inventoryCap - currentInventorySpace));
        }else if ((action.equals("Remove") || action.equals("Use")) && item.getType().equals("PokemonBall")){
            System.out.println("Cant remove occupied pokemonBall");
        }

    }

    public void upgradeToBckPack(int spaceToAdd) {
        inventoryCap += spaceToAdd;
        System.out.println("Upgraded Backpack space to " + inventoryCap);

    }

    private boolean hasRoom(Item item) {
        if (item == null) {
            return false;
        } else return inventoryCap > currentInventorySpace;

    }

    public void managePokemons(Pokemon pokemon , String action) {

        if (pokemon != null) {
            if (action.equals("Add")) {
                pokemonArrayList.add(pokemon);
                System.out.println("You have captured " + pokemon.getName() + "!!!");
                pokemon.createBall(pokemon);
                System.out.println(pokemon.getPokemonBall().getType());
                if (hasRoom(pokemon.getPokemonBall())) {
                    System.out.println("Added " + pokemon.getName() + " successfully! \nSpace left in backPack : " + (inventoryCap - currentInventorySpace));
                    itemArrayList.add(pokemon.getPokemonBall());
                }
            }
            else if(action.equals("Remove")){
                currentInventorySpace -= pokemon.getPokemonBall().getInventorySpaceValue();
                itemArrayList.remove(pokemon.getPokemonBall());
                System.out.println("Removed " + pokemon.getName() + " successfully! \nSpace left in backPack : " + (inventoryCap - currentInventorySpace));
                pokemonArrayList.remove(pokemon);

            }
        }
    }

}



