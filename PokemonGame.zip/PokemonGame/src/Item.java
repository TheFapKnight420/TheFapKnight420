public class Item {
    private String name;
    private String type;
    private int inventorySpaceValue;

    public Item(String name, String type, int inventorySpaceValue) {
        this.name = name;
        this.type = type;
        this.inventorySpaceValue = inventorySpaceValue;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public int getInventorySpaceValue() {
        return inventorySpaceValue;
    }

    public void setName(String name) {
        this.name = name;
    }
}
